import com.nkit.extractor.NkitReader;
import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.file.*;
import java.util.List;

/** Tes di PC: java -cp out NkitTest game.nkit.iso outdir */
public class NkitTest {
    public static void main(String[] a) throws Exception {
        try (FileChannel ch = FileChannel.open(Paths.get(a[0]), StandardOpenOption.READ)) {
            NkitReader r = new NkitReader(ch);
            List<NkitReader.Entry> list = r.list();
            System.out.println(r.kind() + ", entri " + list.size() + ", bytes " + NkitReader.totalBytes(list)
                    + (r.warning() != null ? ", PERINGATAN: " + r.warning() : ""));
            Path root = Paths.get(a[1]);
            byte[] buf = new byte[1 << 20];
            for (NkitReader.Entry e : list) {
                Path p = root.resolve(e.path);
                if (e.dir) { Files.createDirectories(p); continue; }
                Files.createDirectories(p.getParent());
                try (OutputStream os = Files.newOutputStream(p)) { r.extract(e, os, buf, null, null); }
                System.out.println((e.isGenerated() ? "[junk] " : "       ") + e.path + " " + e.size);
            }
        }
    }
}
