#!/usr/bin/env python3
"""Membuat image NKit sintetis (GameCube / Wii) + file hasil yang diharapkan, untuk menguji NkitReader.
Penulis gap mengikuti NKitAsIso.cs; generator junk ditulis ulang terpisah dari NJunk.cs."""
import os, struct, sys, random

M = 0xFFFFFFFF
def be(v): return struct.pack('>I', v & M)

# ---------------- generator junk (port independen dari NJunk.cs)
def junk_block(idb, disc, start, full, fs_off):
    BLOCK, SECT = 0x40000, 0x8000
    buf = bytearray(BLOCK)
    if start > fs_off + BLOCK: return bytes(buf)
    junk_size = min(max(0, full - (full % SECT) - fs_off), BLOCK)
    seed = ((((idb[2] << 8) | idb[1]) << 16) | ((idb[3] + idb[2]) << 8) | (idb[0] + idb[1])) & M
    seed ^= disc
    i = 0
    while i < junk_size:
        o = fs_off + i
        x = ((seed * 0x260bcd5) & M) ^ (((((o // BLOCK) * 8 * 0x1ef29123) & M) + ((0x1ef29123 * ((o % BLOCK) // SECT)) & M)) & M)
        j = [0] * 521
        for k in range(17):
            val = 0
            for _ in range(32):
                x = (x * 0x5d588b65) & M
                x = (x + 1) & M
                val = ((val >> 1) | (x & 0x80000000)) & M
            j[k] = val
        j[16] = (j[16] ^ (j[0] >> 9) ^ ((j[16] << 23) & M)) & M
        for k in range(17, 521):
            j[k] = (((j[k-17] << 23) & M) ^ (j[k-16] >> 9) ^ j[k-1]) & M
        def gen():
            for k in range(32): j[k] ^= j[k + 489]
            for k in range(32, 521): j[k] ^= j[k - 32]
        for _ in range(4): gen()
        idx = 0
        p = i
        end = i + SECT
        while p < end:
            if p != i:
                idx += 1
                if idx == 521:
                    gen(); idx = 0
            v = j[idx]
            buf[p] = (v >> 24) & 0xFF
            buf[p+1] = (v >> 0x12) & 0xFF
            buf[p+2] = (v >> 8) & 0xFF
            buf[p+3] = v & 0xFF
            p += 4
        i += SECT
    if start > fs_off:
        for k in range(int(start - fs_off)): buf[k] = 0
    return bytes(buf)

def junk_bytes(idb, disc, start, full, abs_off, n):
    out = bytearray()
    while n > 0:
        bs = abs_off // 0x40000 * 0x40000
        blk = junk_block(idb, disc, start, full, bs)
        inb = abs_off - bs
        take = min(0x40000 - inb, n)
        out += blk[inb:inb + take]
        abs_off += take; n -= take
    return bytes(out)

def rnd(seed, n):
    r = random.Random(seed)
    return bytes(r.randrange(256) for _ in range(n))

def align4(n): return n + (-n % 4)

def build(wii, outdir):
    mult = 4 if wii else 1
    contents = {
        'a1.bin': rnd(1, 1001),
        'a2.txt': rnd(2, 5000),
        'last.bin': rnd(3, 2000),
    }
    names = ['DirA', 'a1.bin', 'a2.txt', 'empty.bin', 'junk.bin', 'last.bin']
    # tabel nama
    nt = b''; noff = {}
    for n in names:
        noff[n] = len(nt); nt += n.encode('ascii') + b'\0'
    nent = 7
    fst_size = 12 * nent + len(nt)
    fst_size_al = align4(fst_size)
    if wii: fst_size = fst_size_al   # FST Wii selalu kelipatan 4 (disimpan dalam satuan dword)
    flags_len = 4 if wii else 0

    # --- posisi (compact) dihitung dari awal "ruang source": untuk GC = posisi file, Wii = relatif sub-header
    fst_off = 0x2500 if not wii else 0x2500          # byte (ruang partisi untuk Wii)
    head_end = fst_off + fst_size_al
    pos = head_end + (flags_len if wii else 0)
    dst = (fst_off + fst_size) if wii else head_end   # fsPos / dstPos awal
    src = pos
    parts = []   # urutan penulisan di source
    offs = {}
    jid = b'GTST' if not wii else b'RTST'
    disc = 0
    junk_len = 3000; junk_nulls = 2
    expect = {}
    junk_dst = None

    # gap awal: AllJunk 0x1000 (+4 pad)
    parts.append(be(0x1000 | 0) + b'\0\0\0\0'); src += 8; dst += 0x1000
    offs['a1.bin'] = src
    parts.append(contents['a1.bin'] + b'\0' * (align4(1001) - 1001)); src += align4(1001); dst += align4(1001)
    # gap: AllBlockFilled 0x200
    parts.append(be(0x200 | 1)); src += 4; dst += 0x200
    offs['a2.txt'] = src
    parts.append(contents['a2.txt']); src += 5000; dst += 5000
    # gap: Mixed 0x300 (NonJunk 256 raw, ByteFill 256 of 0x41, Junk 256)
    raw = rnd(9, 256)
    parts.append(be(0x300 | 2) + be((1 << 30) | 1) + raw + be((2 << 30) | (1 << 8) | 0x41) + be((0 << 30) | 1))
    src += 4 + 4 + 256 + 4 + 4; dst += 0x300
    offs['empty.bin'] = src
    parts.append(be(0)); src += 4                      # gap kosong setelah empty.bin
    offs['junk.bin'] = src
    junk_dst = dst
    parts.append(be((junk_nulls << 2) | 3) + be(junk_len) + be(0x400 | 0)); src += 12
    dst += align4(junk_len) if wii else (junk_nulls + (align4(junk_len) - junk_nulls)); dst += 0x400
    offs['last.bin'] = src
    parts.append(contents['last.bin']); src += 2000; dst += 2000
    if wii:
        part_fs = 0x7c00 * 8
        final = part_fs - dst
    else:
        image_size = 0x40000
        final = image_size - dst
    assert final > 0
    parts.append(be(final | 0)); src += 4
    body = b''.join(parts)

    # FST
    fst = bytearray()
    fst += struct.pack('>BBBBII', 1, 0, 0, 0, 0, nent)                        # root
    fst += struct.pack('>I', (1 << 24) | noff['DirA']) + be(0) + be(4)         # DirA: 1..3
    for nme in ['a1.bin', 'a2.txt']:
        fst += be(noff[nme]) + be(offs[nme] // mult) + be(len(contents[nme]))
    fst += be(noff['empty.bin']) + be(offs['empty.bin'] // mult) + be(0)
    fst += be(noff['junk.bin']) + be(offs['junk.bin'] // mult) + be(0)         # ukuran 0 di FST
    fst += be(noff['last.bin']) + be(offs['last.bin'] // mult) + be(len(contents['last.bin']))
    fst += nt
    fst = bytes(fst) + b'\0' * (fst_size_al - len(fst))
    assert len(fst) == fst_size_al

    boot = bytearray(0x440)
    boot[0:4] = jid
    boot[6] = disc
    boot[0x20:0x28] = b'TESTGAME'
    boot[0x424:0x428] = be(fst_off // mult)
    boot[0x428:0x42c] = be(fst_size // mult if wii else fst_size)
    boot[0x200:0x208] = b'NKIT v01'

    hdr_to_fst = b'\0' * (fst_off - 0x440)
    flags = b'\0' * flags_len

    if not wii:
        image = bytearray(boot)
        image[0x1c:0x20] = be(0xC2339F3D)
        image[0x210:0x214] = be(image_size)
        image[0x214:0x218] = b'\0\0\0\0'
        image += hdr_to_fst + fst
        # lompat ke posisi file pertama: head_end sudah = len(image)
        assert len(image) == head_end, (len(image), head_end)
        image += body
        path = os.path.join(outdir, 'test_gc.nkit.iso')
        ctx = (jid, disc, 0, image_size)
    else:
        part_off = 0x58000
        phb = 0x8000
        hashed = part_fs // 0x7c00 * 0x8000
        boot[0x210:0x214] = be(hashed // 4)
        sub = bytes(boot) + hdr_to_fst + fst + flags + body
        head = bytearray(0x50000)
        head[0:4] = b'RTST'; head[0x18:0x1c] = be(0x5D1C9EA3); head[0x200:0x208] = b'NKIT v01'
        head[0x40000:0x40004] = be(1); head[0x40004:0x40008] = be(0x40020 // 4)
        head[0x40020:0x40024] = be(part_off // 4); head[0x40024:0x40028] = be(0)
        phdr = bytearray(phb); phdr[0x2b8:0x2bc] = be(phb // 4)
        image = bytes(head) + b'\0' * (part_off - 0x50000) + bytes(phdr) + sub
        path = os.path.join(outdir, 'test_wii.nkit.iso')
        ctx = (jid, disc, fst_off + fst_size + 0x1c, part_fs)
        image = bytearray(image)

    open(path, 'wb').write(image)
    exp = os.path.join(outdir, 'expected_wii' if wii else 'expected_gc')
    base = os.path.join(exp, 'DATA') if wii else exp
    os.makedirs(os.path.join(base, 'DirA'), exist_ok=True)
    open(os.path.join(base, 'DirA', 'a1.bin'), 'wb').write(contents['a1.bin'])
    open(os.path.join(base, 'DirA', 'a2.txt'), 'wb').write(contents['a2.txt'])
    open(os.path.join(base, 'empty.bin'), 'wb').write(b'')
    open(os.path.join(base, 'last.bin'), 'wb').write(contents['last.bin'])
    jb = bytes(junk_nulls) + junk_bytes(ctx[0], ctx[1], ctx[2], ctx[3], junk_dst + junk_nulls, junk_len - junk_nulls)
    open(os.path.join(base, 'junk.bin'), 'wb').write(jb)
    print('ok', path, len(image))

if __name__ == '__main__':
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    build(False, out)
    build(True, out)
