package com.nkit.extractor;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CancellationException;

/**
 * Pembaca file *.nkit.iso (format "NKIT v01") untuk GameCube dan Wii. Java murni, tanpa kelas
 * Android, jadi bisa dites di PC. Hanya untuk MEMBACA / MENGEKSTRAK file, tidak membuat ulang ISO.
 *
 * Dasar format (dipelajari dari NKitAsIso.cs / NKitAsIso.Wii.cs di NKit 3.2.0):
 *  - GameCube: tabel FST di file nkit masih berisi offset file = posisi file itu di dalam file nkit,
 *    jadi file bisa dibaca langsung. Satu-satunya pengecualian adalah "junk file" (file berukuran 0
 *    di FST yang isi aslinya hanya pola junk disc); ukurannya disimpan di kata gap setelah file,
 *    dan isinya dibuat ulang dengan generator junk yang sama seperti NKit.
 *  - Wii: partisi disimpan tanpa enkripsi dan tanpa hash. Offset file di FST (x4) relatif terhadap
 *    sub-header partisi di dalam file nkit.
 */
public final class NkitReader {

    public interface Cancel {
        boolean isCancelled();
    }

    public interface Progress {
        void onBytes(long bytes);
    }

    // ------------------------------------------------------------------ konstanta
    private static final int BOOT_SIZE = 0x440;
    private static final int DOL_PTR = 0x420;
    private static final int FST_PTR = 0x424;
    private static final int FST_SIZE = 0x428;
    private static final int NKIT_HDR = 0x200;
    private static final int APPLOADER = 0x2440;
    private static final long GC_MAGIC = 0xC2339F3DL;
    private static final long WII_MAGIC = 0x5D1C9EA3L;
    private static final int WII_PTN_TABLE = 0x40000;
    private static final int MAX_FST = 64 * 1024 * 1024;
    private static final int NULLS_COUNT = 0x1c;
    private static final long GAP_BLOCK = 0x100;

    // ------------------------------------------------------------------ tipe publik
    public static final class Entry {
        public final String path;      // relatif, dipisah '/', tanpa '/' di depan
        public final boolean dir;
        public final long size;
        final long position;           // posisi byte data di file nkit (-1 bila dibuat ulang dari junk)
        final Junk junk;               // null untuk file biasa

        Entry(String path, boolean dir, long size, long position, Junk junk) {
            this.path = path;
            this.dir = dir;
            this.size = size;
            this.position = position;
            this.junk = junk;
        }

        public String name() {
            return path.substring(path.lastIndexOf('/') + 1);
        }

        public String parent() {
            int i = path.lastIndexOf('/');
            return i < 0 ? "" : path.substring(0, i);
        }

        /** Posisi data di file nkit, atau -1 untuk junk file yang dibuat ulang. */
        public long position() {
            return position;
        }

        public boolean isGenerated() {
            return junk != null;
        }
    }

    // ------------------------------------------------------------------ tipe internal
    /** Konteks generator junk (id disc, nomor disc, dst). */
    static final class Ctx {
        final byte[] id;
        final int disc;
        final long start;   // startOffset untuk NJunk.Fill
        final long full;    // fullSize untuk NJunk.Fill

        Ctx(byte[] id, int disc, long start, long full) {
            this.id = id;
            this.disc = disc;
            this.start = start;
            this.full = full;
        }
    }

    /** Junk file: [0,nulls) nol, sisanya junk pada offset absolut dst+k di ruang disc/partisi. */
    static final class Junk {
        final long nulls;
        final long dst;
        final Ctx ctx;

        Junk(long nulls, long dst, Ctx ctx) {
            this.nulls = nulls;
            this.dst = dst;
            this.ctx = ctx;
        }
    }

    /** Node pohon FST. */
    private static final class Node {
        String name = "";
        String path = "";
        boolean dir;
        boolean hidden;          // nama berbahaya / tidak valid: jangan ditampilkan
        long off;
        long size;
        long junkSize = -1;      // diisi bila ketemu junk file
        long junkNulls;
        long junkDst;
        Ctx ctx;                 // konteks junk bila junkSize > 0
        final List<Node> files = new ArrayList<>();
        final List<Node> dirs = new ArrayList<>();
    }

    private static final class Fst {
        Node root;
        boolean invalidEntry;    // ada file berukuran >0 dengan offset 0 (FST rusak)
    }

    // ------------------------------------------------------------------ state
    private final FileChannel ch;
    private final long fileSize;
    private boolean wii;
    private boolean nkit;
    private String warning;
    private int junkFileCount;
    private final JunkGen gen = new JunkGen();

    public NkitReader(FileChannel channel) throws IOException {
        this.ch = channel;
        this.fileSize = channel.size();
        if (fileSize < APPLOADER + 0x20) throw new IOException("File terlalu kecil, bukan image GameCube/Wii");

        byte[] head = new byte[APPLOADER + 0x0a];
        readFully(head, 0, head.length, 0);

        if (u32le(head, 0) == 0xB10BC001L) {
            throw new IOException("Ini .nkit.gcz (terkompresi). Ekstrak dulu menjadi .nkit.iso, format ini belum didukung");
        }
        if (new String(head, 0, 4, StandardCharsets.US_ASCII).equals("WBFS")) {
            throw new IOException("Ini file WBFS, bukan nkit.iso");
        }

        String marker = new String(head, NKIT_HDR, 4, StandardCharsets.US_ASCII);
        nkit = marker.equals("NKIT");
        if (nkit) {
            String ver = new String(head, NKIT_HDR, 8, StandardCharsets.US_ASCII);
            if (!ver.equals("NKIT v01")) throw new IOException("Versi NKit tidak didukung: " + ver);
        }

        boolean gc = u32(head, 0x1c) == GC_MAGIC;
        wii = u32(head, 0x18) == WII_MAGIC;
        if (!gc && !wii) {
            // GameCube tanpa magic standar (demo): id tidak nol, judul tidak nol, tanggal apploader YYYY/MM/DD
            String date = new String(head, APPLOADER, 10, StandardCharsets.US_ASCII);
            gc = u32(head, 0) != 0 && u32(head, 0x20) != 0 && date.matches(".*[0-9]{4}/[0-9]{2}/[0-9]{2}$");
        }
        if (!gc && !wii) throw new IOException("Bukan image GameCube/Wii yang valid");
        if (wii && !nkit) {
            throw new IOException("ISO Wii asli terenkripsi. App ini hanya membuka NKit untuk Wii (nkit.iso)");
        }
    }

    public boolean isWii() {
        return wii;
    }

    public boolean isNkit() {
        return nkit;
    }

    /** Teks ringkas jenis image, untuk status. */
    public String kind() {
        return (wii ? "Wii" : "GameCube") + (nkit ? " NKit" : " ISO");
    }

    /** Peringatan dari proses baca (mis. junk file tidak bisa dipulihkan), atau null. */
    public String warning() {
        return warning;
    }

    // ------------------------------------------------------------------ daftar file
    /** Mendaftar semua folder dan file. Parent selalu muncul sebelum child. */
    public List<Entry> list() throws IOException {
        List<Entry> out = new ArrayList<>();
        junkFileCount = 0;
        if (wii) listWii(out); else listGc(out);

        Collections.sort(out, new Comparator<Entry>() {
            @Override public int compare(Entry a, Entry b) {
                return a.path.compareToIgnoreCase(b.path);
            }
        });
        return out;
    }

    public static long totalBytes(List<Entry> entries) {
        long t = 0;
        for (Entry e : entries) if (!e.dir) t += e.size;
        return t;
    }

    // ------------------------------------------------------------------ GameCube
    private void listGc(List<Entry> out) throws IOException {
        byte[] hdr = new byte[BOOT_SIZE];
        readFully(hdr, 0, hdr.length, 0);
        long fstOff = u32(hdr, FST_PTR);
        long fstSize = u32(hdr, FST_SIZE);
        if (fstOff < BOOT_SIZE || fstSize < 12 || fstSize > MAX_FST || fstOff + fstSize > fileSize) {
            throw new IOException("Tabel file (FST) tidak valid, image rusak?");
        }
        byte[] fstBytes = new byte[(int) fstSize];
        readFully(fstBytes, 0, fstBytes.length, fstOff);

        Fst fst = parseFst(fstBytes, 1L);
        List<Node> files = orderedFiles(fst.root);

        for (Node f : files) {
            if (f.hidden || f.size == 0) continue;
            if (f.off == 0) { f.hidden = true; continue; }
            if (f.off + f.size > fileSize) {
                throw new IOException("File '" + f.path + "' melewati akhir image (file terpotong?)");
            }
        }

        if (nkit && !fst.invalidEntry && hasEmptyFile(files)) {
            long imageSize = u32(hdr, NKIT_HDR + 0x10);
            byte[] junkId = new byte[4];
            System.arraycopy(hdr, NKIT_HDR + 0x14, junkId, 0, 4);
            if (isZero(junkId)) System.arraycopy(hdr, 0, junkId, 0, 4);
            Ctx ctx = new Ctx(junkId, hdr[6] & 0xFF, 0, imageSize);
            try {
                walkGc(files, hdr, fstOff, fstSize, imageSize);
            } catch (IOException ex) {
                clearJunk(files);
                warning = "Junk file tidak bisa dipulihkan: " + ex.getMessage();
            }
            applyJunk(files, ctx);
        }

        addEntries(fst.root, "", 0, out);
    }

    /** Port dari NKitAsIso.ParseGameCube, hanya untuk menghitung posisi hasil dekode (dst). */
    private void walkGc(List<Node> files, byte[] hdr, long fstOff, long fstSize, long imageSize) throws IOException {
        if (files.isEmpty()) return;
        long fstAligned = fstSize + (fstSize % 4 == 0 ? 0 : 4 - (fstSize % 4));
        Walk w = new Walk(false, fileSize);
        w.src = fstOff + fstAligned;
        w.dst = fstOff + fstAligned;
        long mainDol = u32(hdr, DOL_PTR);

        Node first = files.get(0);
        long firstGapLen = first.off - w.src;
        if (firstGapLen > 0 && w.dst < imageSize) {
            w.gap(first, true, firstGapLen);
            // DOL yang dipindah: berada antara FST dan file pertama
            if (w.src == mainDol && w.src + 0xD8 <= fileSize) {
                long dolSize = 0;
                for (int di = 0; di < 18; di++) {
                    long secOff = w.u32(w.src + di * 4L);
                    long secSize = w.u32(w.src + 0x90 + di * 4L);
                    if (secOff > 0 && secSize > 0) dolSize = Math.max(dolSize, secOff + secSize);
                }
                if (dolSize > 0) {
                    long dolAligned = dolSize + (dolSize % 4 == 0 ? 0 : 4 - dolSize % 4);
                    dolAligned = Math.min(dolAligned, imageSize - w.dst);
                    long toCopy = Math.min(dolAligned, fileSize - w.src);
                    if (toCopy > 0) {
                        w.src += toCopy;
                        w.dst += toCopy;
                    }
                    long post = first.off - w.src;
                    if (post > 0 && w.dst < imageSize) w.gap(null, false, post);
                }
            }
        }

        for (int i = 0; i < files.size(); i++) {
            Node ff = files.get(i);
            boolean isLast = i == files.size() - 1;
            if (w.src < ff.off) w.src = ff.off;

            long size = ff.size;
            if (size > 0) {
                long aligned = size + (size % 4 == 0 ? 0 : 4 - (size % 4));
                aligned = Math.min(aligned, imageSize - w.dst);
                long toCopy = Math.min(aligned, fileSize - w.src);
                if (toCopy > 0) {
                    w.src += toCopy;
                    w.dst += toCopy;
                }
            }
            long gapLen = isLast ? fileSize - w.src : files.get(i + 1).off - w.src;
            if (gapLen > 0 && w.dst < imageSize) w.gap(ff, isLast, gapLen);
        }

        long finalGap = fileSize - w.src;
        if (finalGap > 0 && w.dst < imageSize) w.gap(null, true, finalGap);

        if (w.dst != imageSize) {
            throw new IOException("ukuran hasil dekode tidak cocok (0x" + Long.toHexString(w.dst)
                    + " dari 0x" + Long.toHexString(imageSize) + ")");
        }
    }

    // ------------------------------------------------------------------ Wii
    private static final class Partition {
        long discOffset;
        long type;
    }

    private void listWii(List<Entry> out) throws IOException {
        List<Partition> parts = new ArrayList<>();
        byte[] table = new byte[0x20];
        readFully(table, 0, table.length, WII_PTN_TABLE);
        for (int t = 0; t < 4; t++) {
            long count = u32(table, t * 8);
            long tableOffset = u32(table, t * 8 + 4) * 4L;
            if (count == 0) continue;
            if (count > 32 || tableOffset <= 0 || tableOffset + count * 8 > fileSize) {
                throw new IOException("Tabel partisi Wii tidak valid");
            }
            byte[] ent = new byte[(int) count * 8];
            readFully(ent, 0, ent.length, tableOffset);
            for (int i = 0; i < count; i++) {
                Partition p = new Partition();
                p.discOffset = u32(ent, i * 8) * 4L;
                p.type = u32(ent, i * 8 + 4);
                parts.add(p);
            }
        }
        Collections.sort(parts, new Comparator<Partition>() {
            @Override public int compare(Partition a, Partition b) {
                return Long.compare(a.discOffset, b.discOffset);
            }
        });
        if (parts.isEmpty()) throw new IOException("Tidak ada partisi di image Wii ini");

        int idxData = 0, idxUpd = 0, idxChan = 0, idxOther = 0;
        for (Partition p : parts) {
            String base;
            int n;
            if (p.type == 0) { base = "DATA"; n = ++idxData; }
            else if (p.type == 1) { base = "UPDATE"; n = ++idxUpd; }
            else if (p.type == 2) { base = "CHANNEL"; n = ++idxChan; }
            else { base = "PART" + p.type; n = ++idxOther; }
            String name = n > 1 ? base + "_" + n : base;
            try {
                listWiiPartition(p, name, out);
            } catch (IOException ex) {
                String m = "Partisi " + name + ": " + ex.getMessage();
                warning = warning == null ? m : warning + "\n" + m;
            }
        }
        if (out.isEmpty() && warning != null) throw new IOException(warning);
    }

    private void listWiiPartition(Partition p, String name, List<Entry> out) throws IOException {
        long ps = p.discOffset;
        if (ps <= 0 || ps + 0x2c0 > fileSize) throw new IOException("posisi partisi di luar file");

        long phb = readU32(ps + 0x2b8) * 4L;                      // ukuran blok header partisi
        if (phb <= 0 || phb > 0x100000 || ps + phb + BOOT_SIZE > fileSize) {
            throw new IOException("header partisi tidak valid");
        }
        long sub = ps + phb;                                       // sub-header partisi (boot.bin)
        byte[] subHdr = new byte[BOOT_SIZE];
        readFully(subHdr, 0, subHdr.length, sub);

        if (u32(subHdr, 0) == 0) return;                           // partisi "wiped": tidak ada file

        long hashedSize = u32(subHdr, NKIT_HDR + 0x10) * 4L;
        long partFsSize = hashedSize / 0x8000 * 0x7c00 + hashedSize % 0x8000;
        long fstOff = u32(subHdr, FST_PTR) * 4L;
        long fstSize = u32(subHdr, FST_SIZE) * 4L;
        if (fstOff < BOOT_SIZE || fstSize < 12 || fstSize > MAX_FST || sub + fstOff + fstSize > fileSize) {
            throw new IOException("tabel file (FST) tidak valid");
        }
        byte[] fstBytes = new byte[(int) fstSize];
        readFully(fstBytes, 0, fstBytes.length, sub + fstOff);

        Fst fst = parseFst(fstBytes, 4L);
        List<Node> files = orderedFiles(fst.root);

        for (Node f : files) {
            if (f.hidden || f.size == 0) continue;
            if (f.off == 0) { f.hidden = true; continue; }
            if (sub + f.off + f.size > fileSize) {
                throw new IOException("file '" + f.path + "' melewati akhir image (file terpotong?)");
            }
        }

        if (!fst.invalidEntry && hasEmptyFile(files) && partFsSize > 0) {
            byte[] junkId = new byte[4];
            System.arraycopy(subHdr, 0, junkId, 0, 4);
            long junkStart = fstOff + fstSize + (fstOff + fstSize == 0 ? 0L : NULLS_COUNT);
            Ctx ctx = new Ctx(junkId, subHdr[6] & 0xFF, junkStart, partFsSize);
            try {
                walkWii(files, sub, fstOff, fstSize, partFsSize);
            } catch (IOException ex) {
                clearJunk(files);
                String m = "Partisi " + name + ": junk file tidak bisa dipulihkan: " + ex.getMessage();
                warning = warning == null ? m : warning + "\n" + m;
            }
            applyJunk(files, ctx);
        }

        out.add(new Entry(name, true, 0, 0, null));
        addEntries(fst.root, name + "/", sub, out);
    }

    /** Port dari bagian walk di NKitAsIso.parseWiiPartition (hanya hitung posisi FS hasil dekode). */
    private void walkWii(List<Node> files, long sub, long fstOff, long fstSize, long partFsSize) throws IOException {
        if (files.isEmpty()) return;
        long flagsLen = hashFlagsLength(partFsSize);
        long headLen = fstOff + fstSize;                          // 0x440 + hdrToFst + FST
        Walk w = new Walk(true, fileSize);
        w.dst = headLen;
        w.src = sub + headLen + flagsLen;

        Node first = files.get(0);
        long firstGapLen = first.off - w.dst - flagsLen;
        if (firstGapLen > 0 && w.dst < partFsSize) {
            long start = w.src;
            w.gap(first, true, firstGapLen);
            if (w.src - start < firstGapLen) w.src = start + firstGapLen;
        }

        for (int i = 0; i < files.size(); i++) {
            Node ff = files.get(i);
            boolean isLast = i == files.size() - 1;
            long size = ff.size;
            long aligned = size + (size % 4 == 0 ? 0 : 4 - (size % 4));
            if (size > 0) {
                long runLen = Math.min(aligned, partFsSize - w.dst);
                if (runLen > 0) w.dst += runLen;
                w.src += aligned;
            }
            long fileEnd = ff.off + aligned;
            long next = isLast ? partFsSize : files.get(i + 1).off;
            long gapLen = next - fileEnd;
            if (gapLen > 0 && w.dst < partFsSize) {
                long start = w.src;
                w.gap(ff, isLast, gapLen);
                if (!isLast && w.src - start < gapLen) w.src = start + gapLen;
            }
        }

        if (w.dst != partFsSize) {
            throw new IOException("ukuran hasil dekode tidak cocok (0x" + Long.toHexString(w.dst)
                    + " dari 0x" + Long.toHexString(partFsSize) + ")");
        }
    }

    private static long hashFlagsLength(long partitionFsSize) {
        long size = partitionFsSize / 0x7c00 * 0x8000;
        long groups = size / 0x200000L + (size % 0x200000L == 0 ? 0 : 1);
        long ints = groups / 32 + (groups % 32 == 0 ? 0 : 1);
        return ints * 4;
    }

    // ------------------------------------------------------------------ decoder gap (bersama GC & Wii)
    private final class Walk {
        final boolean wii;
        final long srcLen;
        long src;
        long dst;
        Walk(boolean wii, long srcLen) {
            this.wii = wii;
            this.srcLen = srcLen;
        }

        long u32(long pos) throws IOException {
            return readU32(pos);
        }

        /** Port parseGcGap / decodeWiiFsGap. Posisi "nulls" tidak memengaruhi dst jadi dibuang. */
        void gap(Node file, boolean firstOrLast, long gapLen) throws IOException {
            if (gapLen == 0) return;
            if (src + 4 > srcLen) return;

            long size = u32(src);
            src += 4;
            int gt = (int) (size & 3);
            size &= 0xFFFFFFFCL;
            if (size == 0xFFFFFFFCL) {
                size = 0xFFFFFFFCL + u32(src);
                src += 4;
            }

            if (gt == 3) {                       // JunkFile
                long nulls = (size & 0xFC) >> 2;
                long junkLen = u32(src);
                src += 4;
                if (file != null && junkLen > 0 && file.size == 0) {
                    file.junkSize = junkLen;
                    file.junkNulls = nulls;
                    file.junkDst = dst;
                }
                long aligned = junkLen + (junkLen % 4 == 0 ? 0 : 4 - (junkLen % 4));
                if (aligned > 0) {
                    if (wii) dst += aligned;
                    else dst += nulls + Math.max(0, aligned - nulls);
                }
                if (gapLen <= 8) return;
                size = u32(src);
                src += 4;
                gt = (int) (size & 3);
                size &= 0xFFFFFFFCL;
            }

            if (size == 0) return;

            if (gt == 0 || gt == 1) {            // AllJunk / AllBlockFilled
                dst += size;
                return;
            }

            long prg = size;                     // Mixed
            int bt = 0;
            while (prg > 0) {
                if (src + 4 > srcLen) break;
                long blk = u32(src);
                src += 4;
                int btType = (int) (blk >>> 30);
                boolean repeat = btType == 3;
                if (!repeat) bt = btType;
                long cnt = blk & 0x3FFFFFFFL;
                long bytes;
                if (bt == 1) {                   // NonJunk: data asli tersimpan di source
                    bytes = Math.min(cnt * GAP_BLOCK, prg);
                    long toCopy = Math.min(bytes, srcLen - src);
                    if (toCopy > 0) src += toCopy;
                } else if (bt == 2) {            // ByteFill
                    if (!repeat) cnt >>= 8;
                    bytes = Math.min(cnt * GAP_BLOCK, prg);
                } else {                         // Junk
                    bytes = Math.min(cnt * GAP_BLOCK, prg);
                }
                prg -= bytes;
                dst += bytes;
            }
        }
    }

    private long readU32(long pos) throws IOException {
        byte[] b = new byte[4];
        readFully(b, 0, 4, pos);
        return u32(b, 0);
    }

    // ------------------------------------------------------------------ FST
    private static Fst parseFst(byte[] fst, long mult) throws IOException {
        if (fst.length < 12) throw new IOException("FST terlalu kecil");
        long nl = u32(fst, 8);
        if (nl < 1 || nl * 12 > fst.length) throw new IOException("Jumlah entri FST tidak valid");
        int n = (int) nl;
        int namesBase = n * 12;
        Charset sjis = charset("Shift_JIS");

        Fst result = new Fst();
        Node root = new Node();
        root.dir = true;
        result.root = root;

        Node[] dirStack = new Node[n + 2];
        int[] endStack = new int[n + 2];
        int sp = 0;
        dirStack[sp] = root;
        endStack[sp] = n;
        sp++;

        for (int i = 1; i < n; i++) {
            while (sp > 1 && endStack[sp - 1] <= i) sp--;
            Node parent = dirStack[sp - 1];
            int p = i * 12;
            long hdr = u32(fst, p);
            int type = (int) (hdr >>> 24);
            int nameOff = (int) (hdr & 0xFFFFFF);
            long a = u32(fst, p + 4);
            long b = u32(fst, p + 8);

            Node nd = new Node();
            nd.name = readName(fst, namesBase + nameOff, sjis);
            nd.hidden = parent.hidden || badName(nd.name);

            if ((type & 1) != 0) {
                nd.dir = true;
                nd.path = parent.path + nd.name + "/";
                parent.dirs.add(nd);
                int end = (int) Math.min(Math.max(b, i + 1L), n);
                dirStack[sp] = nd;
                endStack[sp] = end;
                sp++;
            } else {
                nd.path = parent.path + nd.name;
                nd.off = a * mult;
                nd.size = b;
                if (nd.off == 0 && nd.size > 0) result.invalidEntry = true;
                parent.files.add(nd);
            }
        }
        return result;
    }

    /** Urutan sama seperti Fst.Files di NKit: file per folder dulu, lalu subfolder; stabil by (offset, size). */
    private static List<Node> orderedFiles(Node root) {
        List<Node> out = new ArrayList<>();
        collect(root, out);
        Collections.sort(out, new Comparator<Node>() {
            @Override public int compare(Node x, Node y) {
                int c = Long.compare(x.off, y.off);
                return c != 0 ? c : Long.compare(x.size, y.size);
            }
        });
        return out;
    }

    private static void collect(Node d, List<Node> out) {
        out.addAll(d.files);
        for (Node s : d.dirs) collect(s, out);
    }

    private static boolean hasEmptyFile(List<Node> files) {
        for (Node f : files) if (f.size == 0 && !f.hidden) return true;
        return false;
    }

    private static void clearJunk(List<Node> files) {
        for (Node f : files) f.junkSize = -1;
    }

    private static void applyJunk(List<Node> files, Ctx ctx) {
        for (Node f : files) if (f.junkSize > 0) f.ctx = ctx;
    }

    private void addEntries(Node dir, String prefix, long base, List<Entry> out) {
        for (Node d : dir.dirs) {
            if (d.hidden) continue;
            out.add(new Entry(prefix + dirPath(d), true, 0, 0, null));
            addEntries(d, prefix, base, out);
        }
        for (Node f : dir.files) {
            if (f.hidden) continue;
            String path = prefix + f.path;
            if (f.junkSize > 0 && f.ctx != null) {
                junkFileCount++;
                out.add(new Entry(path, false, f.junkSize, -1, new Junk(f.junkNulls, f.junkDst, f.ctx)));
            } else {
                out.add(new Entry(path, false, f.size, f.size == 0 ? 0 : base + f.off, null));
            }
        }
    }

    private static String dirPath(Node d) {
        String p = d.path;
        return p.endsWith("/") ? p.substring(0, p.length() - 1) : p;
    }

    private static boolean badName(String n) {
        if (n.isEmpty() || n.equals(".") || n.equals("..")) return true;
        for (int i = 0; i < n.length(); i++) {
            char c = n.charAt(i);
            if (c == '/' || c == '\\' || c < 0x20) return true;
        }
        return false;
    }

    private static String readName(byte[] b, int pos, Charset cs) {
        if (pos < 0 || pos >= b.length) return "";
        int e = pos;
        while (e < b.length && b[e] != 0) e++;
        return new String(b, pos, e - pos, cs);
    }

    private static Charset charset(String name) {
        try {
            return Charset.forName(name);
        } catch (Exception ex) {
            return StandardCharsets.ISO_8859_1;
        }
    }

    // ------------------------------------------------------------------ baca / ekstrak
    /** Membaca sampai len byte dari file mulai off (untuk preview). */
    public byte[] read(Entry e, long off, int len) throws IOException {
        if (off >= e.size) return new byte[0];
        int n = (int) Math.min((long) len, e.size - off);
        byte[] b = new byte[n];
        readAt(e, off, b, 0, n);
        return b;
    }

    /** Menyalin isi satu file ke out. */
    public void extract(Entry e, OutputStream out, byte[] buf, Progress progress, Cancel cancel) throws IOException {
        long done = 0;
        while (done < e.size) {
            if (cancel != null && cancel.isCancelled()) throw new CancellationException();
            int n = (int) Math.min(buf.length, e.size - done);
            readAt(e, done, buf, 0, n);
            out.write(buf, 0, n);
            done += n;
            if (progress != null) progress.onBytes(n);
        }
    }

    private void readAt(Entry e, long off, byte[] b, int bo, int n) throws IOException {
        if (e.junk == null) {
            readFully(b, bo, n, e.position + off);
            return;
        }
        int z = (int) Math.max(0, Math.min((long) n, e.junk.nulls - off));
        if (z > 0) Arrays.fill(b, bo, bo + z, (byte) 0);
        if (n > z) gen.read(e.junk.ctx, e.junk.dst + off + z, b, bo + z, n - z);
    }

    private void readFully(byte[] b, int off, int len, long pos) throws IOException {
        ByteBuffer bb = ByteBuffer.wrap(b, off, len);
        while (bb.hasRemaining()) {
            int r = ch.read(bb, pos + bb.position() - off);
            if (r < 0) throw new IOException("Akhir file tak terduga (file terpotong?)");
        }
    }

    // ------------------------------------------------------------------ util
    private static long u32(byte[] b, int o) {
        return ((b[o] & 0xFFL) << 24) | ((b[o + 1] & 0xFFL) << 16) | ((b[o + 2] & 0xFFL) << 8) | (b[o + 3] & 0xFFL);
    }

    private static long u32le(byte[] b, int o) {
        return ((b[o + 3] & 0xFFL) << 24) | ((b[o + 2] & 0xFFL) << 16) | ((b[o + 1] & 0xFFL) << 8) | (b[o] & 0xFFL);
    }

    private static boolean isZero(byte[] b) {
        for (byte x : b) if (x != 0) return false;
        return true;
    }

    // ------------------------------------------------------------------ generator junk (port NJunk.cs)
    /** Port dari NJunk.Fill di NKit. Tidak thread-safe sendiri, jadi dipanggil lewat synchronized. */
    static final class JunkGen {
        static final int BLOCK = 0x40000;
        static final int SECTOR = 0x8000;
        static final int FULL = 521;
        static final int BASE = 17;

        private final byte[] block = new byte[BLOCK];
        private final int[] j = new int[FULL];
        private Ctx cur;
        private long curStart = -1;

        synchronized void read(Ctx c, long absOff, byte[] dst, int dOff, int len) {
            while (len > 0) {
                long bs = absOff / BLOCK * BLOCK;
                int inBlock = (int) (absOff - bs);
                if (cur != c || curStart != bs) {
                    fill(c, bs);
                    cur = c;
                    curStart = bs;
                }
                int n = Math.min(BLOCK - inBlock, len);
                System.arraycopy(block, inBlock, dst, dOff, n);
                absOff += n;
                dOff += n;
                len -= n;
            }
        }

        private void fill(Ctx c, long fsOffset) {
            if (c.start > fsOffset + BLOCK) {
                Arrays.fill(block, (byte) 0);
                return;
            }
            int junkSize = (int) Math.min(Math.max(0, c.full - (c.full % SECTOR) - fsOffset), BLOCK);
            int seed = seed(c.id, c.disc);
            for (int i = 0; i < junkSize; i += SECTOR) {
                stage2(seed, fsOffset + i);
                stage3();
                for (int k = 0; k < 4; k++) gen();
                stage5(i, SECTOR);
            }
            if (BLOCK - junkSize != 0) Arrays.fill(block, junkSize, BLOCK, (byte) 0);
            if (c.start > fsOffset) Arrays.fill(block, 0, (int) (c.start - fsOffset), (byte) 0);
        }

        private static int seed(byte[] id, int disc) {
            int i0 = id[0] & 0xFF, i1 = id[1] & 0xFF, i2 = id[2] & 0xFF, i3 = id[3] & 0xFF;
            return ((((i2 << 8) | i1) << 16) | ((i3 + i2) << 8) | (i0 + i1)) ^ (disc & 0xFF);
        }

        private void stage2(int seed, long fsOffset) {
            int x = (seed * 0x260bcd5)
                    ^ (((int) (fsOffset / BLOCK) * 8 * 0x1ef29123) + (0x1ef29123 * (int) (fsOffset % BLOCK / SECTOR)));
            for (int i = 0; i < BASE; i++) {
                int val = 0;
                for (int c = 0; c < 32; c++) {
                    x *= 0x5d588b65;
                    ++x;
                    val = (val >>> 1) | (x & 0x80000000);
                }
                j[i] = val;
            }
            j[16] ^= (j[0] >>> 9) ^ (j[16] << 23);
        }

        private void stage3() {
            for (int i = BASE; i < FULL; i++) {
                j[i] = (j[i - 17] << 23) ^ (j[i - 16] >>> 9) ^ j[i - 1];
            }
        }

        private void stage5(int offset, int size) {
            if (size > SECTOR) size = SECTOR;
            int end = offset + size;
            for (int idx = 0, i = offset; i < end; i += 4) {
                if (i != offset && ++idx == FULL) {
                    gen();
                    idx = 0;
                }
                int v = j[idx];
                block[i] = (byte) (v >>> 0x18);
                block[i + 1] = (byte) (v >>> 0x12);   // sama persis dengan NKit (kemungkinan bug asli, harus dipertahankan)
                block[i + 2] = (byte) (v >>> 8);
                block[i + 3] = (byte) v;
            }
        }

        private void gen() {
            int i = -1;
            while (++i != 32) j[i] ^= j[i + (FULL - 32)];
            i--;
            while (++i != FULL) j[i] ^= j[i - 32];
        }
    }
}
