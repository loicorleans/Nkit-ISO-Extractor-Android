# NKit Extractor

Aplikasi Android ringan untuk menelusuri, mem-preview, dan **mengekstrak file dari `*.nkit.iso`**
(GameCube dan Wii). Tampilan dan cara pakainya sama seperti Xiso Extractor; yang berbeda hanya
pembaca image-nya (`NkitReader.java`, Java murni, tanpa .NET dan tanpa library tambahan).

## Fitur
- Buka `.nkit.iso` lewat tombol **Buka NKit** atau "Buka dengan" dari file manager.
- Jelajahi isi seperti folder, cari file, preview teks/gambar/hex, lihat info file.
- Pilih beberapa file atau **Ekstrak semua** ke folder pilihan (Storage Access Framework, tanpa izin storage).
- GameCube: `.nkit.iso` v1. Wii: partisi tampil sebagai folder `DATA`, `UPDATE`, `CHANNEL` (opsi lewati UPDATE).
- Tidak memakai internet, tidak mengumpulkan data. Android 7.0 (API 24) ke atas.

## Cara kerja singkat
- GameCube: offset file di FST nkit.iso sama dengan posisi file di dalam nkit.iso, jadi file dibaca langsung.
- Wii: partisi di dalam NKit sudah tidak terenkripsi dan tanpa hash; offset file (x4) relatif terhadap sub-header partisi.
- "Junk file" (file di FST berukuran 0 yang isi aslinya pola junk disc) dipulihkan dengan menjalankan ulang
  dekoder gap NKit dan generator junk yang sama; hasilnya hanya dipakai kalau ukuran hasil dekode cocok persis
  dengan ukuran image/partisi (kalau tidak, ada peringatan).

## Batasan
- Tidak membuat ulang ISO utuh, hanya mengekstrak file (itu tugas NKit asli di PC).
- `.nkit.gcz` (terkompresi) belum didukung; ekstrak ke `.nkit.iso` dulu.
- ISO Wii biasa (terenkripsi) tidak didukung; hanya NKit.
- Folder `sys/` (boot.bin, bi2.bin, apploader.img, main.dol) ikut ditampilkan. Pada Wii, main.dol hanya muncul bila posisinya sebelum FST (kasus umum).

## Build
- GitHub Actions: workflow `.github/workflows/build.yml` menghasilkan `NKitExtractor.apk`.
- Lokal: `./gradlew assembleRelease` (JDK 17 + Android SDK 34).

## Tes di PC (tanpa Android)
```
python3 tools/make_test_nkit.py /tmp/t            # buat image nkit sintetis GC + Wii
javac -d out app/src/main/java/com/nkit/extractor/NkitReader.java tools/NkitTest.java
java -cp out NkitTest /tmp/t/test_gc.nkit.iso /tmp/t/out_gc
```

## Lisensi
MIT. Logika format NKit (gap, FST, junk) berasal dari proyek [NKit](https://github.com/Nanook) oleh Nanook (MIT);
kerangka aplikasi dari Xiso Extractor (MIT). Tidak berafiliasi dengan Nintendo. Hanya gunakan salinan disc milik sendiri.
